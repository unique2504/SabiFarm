from fastapi import FastAPI
from pydantic import BaseModel
import sqlite3
app = FastAPI(title='FarmSabi Dashboard API')

DB = 'dashboard/db.sqlite'

def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS farmers
                 (id INTEGER PRIMARY KEY, name TEXT, phone TEXT, village TEXT)''')
    conn.commit()
    conn.close()

class Farmer(BaseModel):
    name: str
    phone: str
    village: str

@app.on_event('startup')
def startup():
    init_db()

@app.post('/farmers')
def add_farmer(f: Farmer):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('INSERT INTO farmers (name,phone,village) VALUES (?,?,?)', (f.name,f.phone,f.village))
    conn.commit()
    conn.close()
    return {'status':'ok'}

@app.get('/farmers')
def list_farmers():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('SELECT id,name,phone,village FROM farmers')
    rows = c.fetchall()
    conn.close()
    return {'farmers':[dict(id=r[0],name=r[1],phone=r[2],village=r[3]) for r in rows]}
