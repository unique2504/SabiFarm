Farmer Management Dashboard
- React frontend in dashboard/frontend
- FastAPI backend in dashboard/backend
- Uses sqlite for quick start
