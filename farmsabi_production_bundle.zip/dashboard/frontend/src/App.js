import React, {useEffect, useState} from 'react';
import axios from 'axios';
export default function App(){
  const [farmers,setFarmers]=useState([]);
  const [name,setName]=useState('');
  const [phone,setPhone]=useState('');
  const [village,setVillage]=useState('');
  useEffect(()=>{ fetchFarmers() },[]);
  const fetchFarmers = async ()=> {
    const r = await axios.get('http://localhost:8001/farmers');
    setFarmers(r.data.farmers);
  };
  const add = async ()=> {
    await axios.post('http://localhost:8001/farmers', {name,phone,village});
    setName(''); setPhone(''); setVillage('');
    fetchFarmers();
  };
  return (<div style={{padding:20}}>
    <h2>FarmSabi Dashboard</h2>
    <div>
      <input placeholder="name" value={name} onChange={e=>setName(e.target.value)} />
      <input placeholder="phone" value={phone} onChange={e=>setPhone(e.target.value)} />
      <input placeholder="village" value={village} onChange={e=>setVillage(e.target.value)} />
      <button onClick={add}>Add Farmer</button>
    </div>
    <h3>Farmers</h3>
    <ul>{farmers.map(f=><li key={f.id}>{f.name} — {f.phone} — {f.village}</li>)}</ul>
  </div>);
}
