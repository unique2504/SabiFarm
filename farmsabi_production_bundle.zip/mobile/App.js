import React, {useState} from 'react';
import { SafeAreaView, View, Text, Button, TextInput, ScrollView, Image } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import api from './src/api';

export default function App(){
  const [crop,setCrop]=useState('maize');
  const [lat,setLat]=useState('6.5244');
  const [lon,setLon]=useState('3.3792');
  const [planting,setPlanting]=useState(null);
  const [market,setMarket]=useState(null);
  const [photo,setPhoto]=useState(null);
  const [detection,setDetection]=useState(null);

  const pickImage = async ()=>{
    const res = await ImagePicker.launchImageLibraryAsync({mediaTypes: ImagePicker.MediaTypeOptions.Images});
    if(!res.cancelled){
      setPhoto(res.uri);
    }
  };

  const detectDisease = async ()=>{
    if(!photo) return alert('Pick a photo first');
    const r = await api.uploadImageForDisease(photo);
    setDetection(JSON.stringify(r));
  };

  return (
    <SafeAreaView style={{flex:1,padding:16}}>
      <ScrollView>
        <Text style={{fontSize:22,fontWeight:'bold'}}>FarmSabi Mobile</Text>
        <Button title="Pick Image" onPress={pickImage} />
        {photo && <Image source={{uri:photo}} style={{width:200,height:200}} />}
        <Button title="Detect Disease" onPress={detectDisease} />
        {detection && <Text>{detection}</Text>}
        <Text>Crop</Text>
        <TextInput value={crop} onChangeText={setCrop} style={{borderWidth:1,padding:8}} />
        <Text>Lat</Text>
        <TextInput value={lat} onChangeText={setLat} style={{borderWidth:1,padding:8}} />
        <Text>Lon</Text>
        <TextInput value={lon} onChangeText={setLon} style={{borderWidth:1,padding:8}} />
        <Button title="Get Planting Date" onPress={async()=>setPlanting(JSON.stringify(await api.getPlantingDate(crop,lat,lon)))} />
        {planting && <Text>Planting: {planting}</Text>}
        <Button title="Get Market Price" onPress={async()=>setMarket(JSON.stringify(await api.getMarketValue(crop)))} />
        {market && <Text>Market: {market}</Text>}
      </ScrollView>
    </SafeAreaView>
  );
}
