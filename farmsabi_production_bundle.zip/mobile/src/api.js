import axios from 'axios';
const baseURL = 'http://10.0.2.2:8000'; // change as needed

const api = {
  getPlantingDate: async (crop, lat, lon) => {
    const r = await axios.get(`${baseURL}/planting-date`, { params: { crop, lat: parseFloat(lat), lon: parseFloat(lon) }});
    return r.data;
  },
  getMarketValue: async (crop) => {
    const r = await axios.get(`${baseURL}/market-value`, { params: { crop }});
    return r.data;
  },
  uploadImageForDisease: async (uri) => {
    // On Android emulator, you need to convert uri to blob; in Expo you can use fetch
    const form = new FormData();
    const filename = uri.split('/').pop();
    const match = /\.(\w+)$/.exec(filename);
    const type = match ? `image/${match[1]}` : `image`;
    form.append('file', { uri, name: filename, type });
    const r = await axios.post(`${baseURL}/disease`, form, { headers: { 'Content-Type': 'multipart/form-data' }});
    return r.data;
  }
};
export default api;
