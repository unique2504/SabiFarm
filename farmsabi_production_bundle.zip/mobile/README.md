Expo Mobile App
---------------
- Set backend base URL in mobile/src/api.js (default uses Android emulator IP 10.0.2.2)
- Install dependencies: npm install
- Start: expo start
- On Genymotion use host IP 10.0.3.2 or configure accordingly
