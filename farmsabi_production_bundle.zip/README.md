FarmSabi — Production Bundle
===========================
This bundle includes:
- Trainable disease model pipeline (training/)
- Mobile Expo app (mobile/)
- Farmer dashboard (dashboard/)
- CI examples (see .github/)

Follow README.md files inside each folder for running instructions.
