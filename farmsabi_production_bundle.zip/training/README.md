Trainable Disease Model (IITA-ready)
-----------------------------------
This folder contains:
- dataset_template/: expected structure for IITA or custom dataset
- dataset.py: PyTorch Dataset loader
- model.py: ResNet-based classifier (transfer learning)
- train.py: PyTorch Lightning training script
- export.py: export to .pt and ONNX

Dataset structure (example):
training/dataset_template/
  train/
    maize_leaf_spot/
      img1.jpg
    maize_healthy/
  val/
    maize_leaf_spot/
    maize_healthy/

Use the IITA data by placing it into the dataset template structure.
