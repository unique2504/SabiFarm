from pathlib import Path
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms

class IITADataset(Dataset):
    def __init__(self, root, split='train', img_size=256):
        self.root = Path(root)/split
        self.samples = list(self.root.rglob('*.jpg'))
        self.classes = sorted({p.parent.name for p in self.samples})
        self.class2idx = {c:i for i,c in enumerate(self.classes)}
        self.transform = transforms.Compose([
            transforms.Resize((img_size,img_size)),
            transforms.RandomHorizontalFlip(),
            transforms.RandomRotation(10),
            transforms.ToTensor()
        ])
    def __len__(self):
        return len(self.samples)
    def __getitem__(self, idx):
        p = self.samples[idx]
        img = Image.open(p).convert('RGB')
        label = self.class2idx[p.parent.name]
        return self.transform(img), label
