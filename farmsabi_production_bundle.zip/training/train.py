import os
import torch
from torch.utils.data import DataLoader
from pytorch_lightning import LightningModule, Trainer
import pytorch_lightning as pl
from dataset import IITADataset
from model import ResNetClassifier
import torch.nn.functional as F
import torch.optim as optim

class LitModel(LightningModule):
    def __init__(self, num_classes, lr=1e-4):
        super().__init__()
        self.model = ResNetClassifier(num_classes)
        self.lr = lr

    def forward(self, x): return self.model(x)

    def training_step(self, batch, batch_idx):
        x,y = batch
        logits = self(x)
        loss = F.cross_entropy(logits, y)
        acc = (logits.argmax(1)==y).float().mean()
        self.log('train_loss', loss)
        self.log('train_acc', acc)
        return loss

    def validation_step(self, batch, batch_idx):
        x,y = batch
        logits = self(x)
        loss = F.cross_entropy(logits, y)
        acc = (logits.argmax(1)==y).float().mean()
        self.log('val_loss', loss, prog_bar=True)
        self.log('val_acc', acc, prog_bar=True)

    def configure_optimizers(self):
        return optim.Adam(self.parameters(), lr=self.lr)

if __name__ == '__main__':
    data_root = os.environ.get('DATA_ROOT', 'training/dataset_template')
    train_ds = IITADataset(data_root, 'train')
    val_ds = IITADataset(data_root, 'val')
    train_loader = DataLoader(train_ds, batch_size=16, shuffle=True, num_workers=4)
    val_loader = DataLoader(val_ds, batch_size=16, num_workers=4)
    model = LitModel(num_classes=len(train_ds.classes))
    trainer = Trainer(max_epochs=10, accelerator='auto')
    trainer.fit(model, train_loader, val_loader)
    trainer.save_checkpoint('training/checkpoints/iita_disease.ckpt')
