import torch
from model import ResNetClassifier

# replace num_classes accordingly
model = ResNetClassifier(num_classes=4)
ckpt = 'training/checkpoints/iita_disease.ckpt'
# If using PL checkpoint, load state dict accordingly
# model.load_state_dict(torch.load(ckpt)['state_dict'])
# torch.save(model.state_dict(), 'models/disease_model/iita_resnet.pt')
print('Edit this file to map checkpoint formats for export.')
